import { config } from 'dotenv';
config();

import '@/ai/flows/categorize-articles.ts';